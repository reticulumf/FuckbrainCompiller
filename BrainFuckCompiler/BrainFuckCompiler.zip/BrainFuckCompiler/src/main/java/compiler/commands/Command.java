package compiler.commands;

public interface Command {
    void execute();
}
